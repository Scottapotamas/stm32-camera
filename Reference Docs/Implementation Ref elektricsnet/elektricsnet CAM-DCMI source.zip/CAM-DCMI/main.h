/*
 * main.h
 *
 *  Created on: 9 Apr 2015
 *      Author: z3168771
 */

#ifndef MAIN_H_
#define MAIN_H_

void frameEndCb(DCMIDriver* dcmip);
void dmaTxferEndCb(DCMIDriver* dcmip);

#endif /* MAIN_H_ */
